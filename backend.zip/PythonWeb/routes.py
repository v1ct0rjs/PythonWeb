from enum import Enum

class Route(Enum):
    INDEX = "/"
    ENG = "/eng"